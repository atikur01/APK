const mysql = require('mysql');
const axios = require('axios');

// MySQL connection configuration
const connection = mysql.createConnection({
  host: 'atikapps.com',
  user: 'phonedata',
  password: 'A@a11223344!',
  database: 'phonedata'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    //console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  //console.log('Connected to MySQL as id ' + connection.threadId);
});

// Object to keep track of devices for which emails have been sent
let emailedDevices = {};

// Function to reset emailedDevices object every one hour
const resetEmailedDevices = () => {
  emailedDevices = {};
};

// Call resetEmailedDevices function every one hour
setInterval(resetEmailedDevices, 10800000  ); // Every three hour in milliseconds

// Fetch data from MySQL table
const fetchData = () => {
  const query = 'SELECT * FROM devices';
  connection.query(query, (error, results, fields) => {
    if (error) {
      //console.error('Error fetching data from MySQL: ' + error.stack);
      return;
    }
    
    // Process each row
    results.forEach((row) => {
      const lastLoginTime = new Date(row.last_login_time);
      const currentTime = new Date();
      const timeDifference = Math.abs(currentTime.getMinutes() - lastLoginTime.getMinutes()) ;
      
      //console.log(timeDifference);
      // Check if last login time is more than 2 minutes ago
      if (timeDifference > 2 && !emailedDevices[row.device_id]) { // Check if device is offline and email hasn't been sent
        // Prepare email data
        const emailData = {
          subject: row.phone_name + ' is offline since ' + lastLoginTime ,
          plainText: row.phone_name + ' is offline since ' + lastLoginTime + '. Please check the device.',
          toAddress: "atikzvii@gmail.com"
        };

        // Send email using HTTP POST request
        axios.post('http://atikapps.com:3000/send-email', emailData)
          .then(response => {
            //console.log('Email sent successfully:', response.data);
            // Mark the device as emailed
            emailedDevices[row.device_id] = true;
          })
          .catch(error => {
            //console.error('Error sending email:', error);
          });
      }
    });
  });
};

// Call fetchData function every minute
setInterval(fetchData, 10000); // Every minute in milliseconds
